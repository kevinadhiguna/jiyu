# Get user IP address (NodeJS)

Get user IP address, powered by NodeJS.

## Reference

- [Read the User’s IP address in JavaScript](https://medium.com/the-daily-web-analyst/read-the-users-ip-address-in-javascript-9fa5b231af6c)
